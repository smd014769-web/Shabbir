# Online Library Management System

A professional PHP + MySQL library management system for colleges and small institutions.

## Features
- Role-based authentication: Admin and Student
- Secure password hashing with PHP password_hash()
- Prepared SQL statements using PDO
- CSRF protection for POST forms
- Admin dashboard with library statistics
- Book CRUD and inventory tracking
- Student management
- Book issue and return workflow
- Automatic overdue calculation
- Search and pagination
- Student dashboard with current loans and history
- Responsive Bootstrap-based interface
- Centralized configuration and reusable helpers

## Requirements
- PHP 8.1+
- MySQL 8.0+ / MariaDB 10.5+
- Apache/XAMPP/WAMP/LAMP

## Setup
1. Create a MySQL database.
2. Import `database/schema.sql`.
3. Copy the project into your web server directory.
4. Update database credentials in `config/config.php`.
5. Open `public/index.php`.
6. Demo admin: `admin@library.local` / `Admin@123`
7. Demo student: `student@library.local` / `Student@123`

Change demo passwords before real deployment.

## Suggested GitHub repository
`online-library-management-system`

## Tech Stack
PHP, MySQL, HTML5, CSS3, JavaScript, Bootstrap 5, PDO.
