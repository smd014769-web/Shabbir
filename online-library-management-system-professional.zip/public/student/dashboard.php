<?php
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/helpers.php';
require_role('student');
$user=current_user();
$stmt=$pdo->prepare("SELECT l.*, b.title, b.author FROM loans l JOIN books b ON b.id=l.book_id WHERE l.user_id=? ORDER BY l.issued_at DESC");
$stmt->execute([$user['id']]); $loans=$stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Student Dashboard</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light"><nav class="navbar navbar-dark bg-primary"><div class="container"><span class="navbar-brand">Library Portal</span><a class="btn btn-outline-light btn-sm" href="../logout.php">Logout</a></div></nav>
<div class="container py-4"><h2>Hello, <?=e($user['name'])?></h2><p class="text-muted">Your borrowing history</p>
<div class="card border-0 shadow-sm"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Book</th><th>Author</th><th>Issued</th><th>Due</th><th>Status</th></tr></thead><tbody>
<?php foreach($loans as $l): ?><tr><td><?=e($l['title'])?></td><td><?=e($l['author'])?></td><td><?=e($l['issued_at'])?></td><td><?=e($l['due_date'])?></td><td><?=e($l['status'])?></td></tr><?php endforeach; ?>
</tbody></table></div></div></div></body></html>
