<?php
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/helpers.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $loanId=(int)$_POST['loan_id'];
    $pdo->beginTransaction();
    $stmt=$pdo->prepare("UPDATE loans SET status='returned', returned_at=NOW() WHERE id=? AND status='issued'");
    $stmt->execute([$loanId]);
    if ($stmt->rowCount()) {
        $pdo->prepare('UPDATE books b JOIN loans l ON l.book_id=b.id SET b.available_copies=b.available_copies+1 WHERE l.id=?')->execute([$loanId]);
    }
    $pdo->commit();
    flash('success','Book returned.');
    header('Location: loans.php'); exit;
}
$loans=$pdo->query("SELECT l.*, b.title, u.name AS student FROM loans l JOIN books b ON b.id=l.book_id JOIN users u ON u.id=l.user_id ORDER BY l.issued_at DESC")->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Loans</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light"><div class="container py-4"><div class="d-flex justify-content-between"><h2>Loans</h2><a href="dashboard.php">Dashboard</a></div>
<div class="table-responsive card shadow-sm border-0 mt-3"><table class="table mb-0"><thead><tr><th>Student</th><th>Book</th><th>Issued</th><th>Due</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach($loans as $l): ?><tr><td><?=e($l['student'])?></td><td><?=e($l['title'])?></td><td><?=e($l['issued_at'])?></td><td><?=e($l['due_date'])?></td><td><?=e($l['status'])?></td><td><?php if($l['status']==='issued'): ?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="loan_id" value="<?=$l['id']?>"><button class="btn btn-sm btn-success">Return</button></form><?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></div></div></body></html>
