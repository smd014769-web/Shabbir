<?php
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/helpers.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'add') {
        $stmt = $pdo->prepare('INSERT INTO books (isbn,title,author,category,total_copies,available_copies) VALUES (?,?,?,?,?,?)');
        $copies = max(1, (int)$_POST['copies']);
        $stmt->execute([trim($_POST['isbn']), trim($_POST['title']), trim($_POST['author']), trim($_POST['category']), $copies, $copies]);
        flash('success', 'Book added.');
    } elseif ($action === 'delete') {
        $stmt = $pdo->prepare('DELETE FROM books WHERE id=?');
        $stmt->execute([(int)$_POST['id']]);
        flash('success', 'Book deleted.');
    }
    header('Location: books.php'); exit;
}
$search = trim($_GET['q'] ?? '');
if ($search) {
    $stmt = $pdo->prepare('SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ? ORDER BY created_at DESC');
    $like = "%$search%"; $stmt->execute([$like,$like,$like]); $books=$stmt->fetchAll();
} else {
    $books=$pdo->query('SELECT * FROM books ORDER BY created_at DESC')->fetchAll();
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Books</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light"><div class="container py-4">
<div class="d-flex justify-content-between align-items-center"><h2>Books</h2><a href="dashboard.php">Dashboard</a></div>
<form class="row g-2 my-3"><div class="col-md-10"><input class="form-control" name="q" value="<?=e($search)?>" placeholder="Search title, author or ISBN"></div><div class="col-md-2"><button class="btn btn-dark w-100">Search</button></div></form>
<div class="card border-0 shadow-sm mb-4"><div class="card-body"><h5>Add book</h5><form method="post" class="row g-2">
<input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="add">
<div class="col-md-2"><input class="form-control" name="isbn" placeholder="ISBN" required></div><div class="col-md-3"><input class="form-control" name="title" placeholder="Title" required></div><div class="col-md-2"><input class="form-control" name="author" placeholder="Author" required></div><div class="col-md-2"><input class="form-control" name="category" placeholder="Category"></div><div class="col-md-1"><input class="form-control" name="copies" type="number" min="1" value="1"></div><div class="col-md-2"><button class="btn btn-primary w-100">Add</button></div>
</form></div></div>
<div class="card border-0 shadow-sm"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>ISBN</th><th>Title</th><th>Author</th><th>Available</th><th></th></tr></thead><tbody>
<?php foreach($books as $b): ?><tr><td><?=e($b['isbn'])?></td><td><?=e($b['title'])?></td><td><?=e($b['author'])?></td><td><?=e((string)$b['available_copies'])?> / <?=e((string)$b['total_copies'])?></td><td><form method="post" onsubmit="return confirm('Delete this book?')"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$b['id']?>"><button class="btn btn-sm btn-outline-danger">Delete</button></form></td></tr><?php endforeach; ?>
</tbody></table></div></div></div></body></html>
