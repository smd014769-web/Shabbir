<?php
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/helpers.php';
require_role('admin');

$stats = [
    'books' => (int)$pdo->query('SELECT COUNT(*) FROM books')->fetchColumn(),
    'students' => (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetchColumn(),
    'active_loans' => (int)$pdo->query("SELECT COUNT(*) FROM loans WHERE status='issued'")->fetchColumn(),
    'overdue' => (int)$pdo->query("SELECT COUNT(*) FROM loans WHERE status='issued' AND due_date < CURDATE()")->fetchColumn(),
];
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Dashboard</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-light">
<nav class="navbar navbar-dark bg-dark"><div class="container"><span class="navbar-brand">Library Admin</span><a class="btn btn-outline-light btn-sm" href="../logout.php">Logout</a></div></nav>
<div class="container py-4">
<h2>Dashboard</h2><p class="text-muted">Welcome, <?= e(current_user()['name']) ?></p>
<div class="row g-3">
<?php foreach ($stats as $label=>$value): ?><div class="col-md-3"><div class="card border-0 shadow-sm"><div class="card-body"><small class="text-muted text-uppercase"><?= e(str_replace('_',' ',$label)) ?></small><h2><?= $value ?></h2></div></div></div><?php endforeach; ?>
</div>
<div class="mt-4 d-flex gap-2"><a class="btn btn-primary" href="books.php">Manage Books</a><a class="btn btn-secondary" href="loans.php">Manage Loans</a></div>
</div></body></html>
