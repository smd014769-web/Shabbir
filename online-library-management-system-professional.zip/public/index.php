<?php
require_once __DIR__ . '/../config/auth.php';
if (!empty($_SESSION['user'])) {
    $role = $_SESSION['user']['role'];
    header('Location: ' . BASE_URL . ($role === 'admin' ? '/admin/dashboard.php' : '/student/dashboard.php'));
    exit;
}
header('Location: ' . BASE_URL . '/login.php');
exit;
