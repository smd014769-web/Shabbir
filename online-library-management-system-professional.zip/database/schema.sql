CREATE DATABASE IF NOT EXISTS library_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE library_management;

CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','student') NOT NULL DEFAULT 'student',
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE books (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  isbn VARCHAR(30) NOT NULL UNIQUE,
  title VARCHAR(200) NOT NULL,
  author VARCHAR(150) NOT NULL,
  category VARCHAR(100),
  total_copies INT UNSIGNED NOT NULL DEFAULT 1,
  available_copies INT UNSIGNED NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_books_title (title),
  INDEX idx_books_author (author)
);

CREATE TABLE loans (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  book_id INT UNSIGNED NOT NULL,
  issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  due_date DATE NOT NULL,
  returned_at DATETIME NULL,
  status ENUM('issued','returned','overdue') NOT NULL DEFAULT 'issued',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE RESTRICT,
  INDEX idx_loans_user (user_id),
  INDEX idx_loans_status (status)
);

INSERT INTO users (name,email,password_hash,role) VALUES
('System Administrator','admin@library.local','$2y$10$9JtY4z2d4z0V9sPq9m4Z7eWQqgG5G7q7lJ8ZJ7h6c4oQxQ7g2d2eW','admin'),
('Demo Student','student@library.local','$2y$10$8yq5qVq6o7mJmJ7cYcKzUeV4l5oZr7f7vJ2x2xYxYxYxYxYxYxYxY','student');

INSERT INTO books (isbn,title,author,category,total_copies,available_copies) VALUES
('9780132350884','Clean Code','Robert C. Martin','Programming',5,5),
('9780262033848','Introduction to Algorithms','Cormen et al.','Algorithms',3,3),
('9780134685991','Effective Java','Joshua Bloch','Java',4,4);
