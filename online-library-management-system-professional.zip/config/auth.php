<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

function require_login(): void {
    if (empty($_SESSION['user'])) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function require_role(string $role): void {
    require_login();
    if (($_SESSION['user']['role'] ?? '') !== $role) {
        http_response_code(403);
        exit('Access denied.');
    }
}

function current_user(): array {
    return $_SESSION['user'] ?? [];
}
